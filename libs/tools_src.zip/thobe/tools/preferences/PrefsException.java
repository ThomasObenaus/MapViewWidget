/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Tools
 */
package thobe.tools.preferences;

/**
 * @author Thomas Obenaus
 * @source PrefsException.java
 * @date 25.08.2009
 */
@SuppressWarnings ( "serial")
public class PrefsException extends Exception
{
	public PrefsException( String cause )
	{
		super( cause );
	}
}
