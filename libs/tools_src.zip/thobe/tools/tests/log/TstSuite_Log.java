/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Tools
 */
package thobe.tools.tests.log;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * @author Thomas Obenaus
 * @source TstSuite_Log.java
 * @date 29.03.2012
 */
@RunWith ( Suite.class)
@Suite.SuiteClasses ( {Tst_TXTLogFormatter.class })
public class TstSuite_Log
{

}


