/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Tools
 */
package thobe.tools.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import thobe.tools.tests.log.TstSuite_Log;

/**
 * @author Thomas Obenaus
 * @source TstSuite_Tools.java
 * @date 29.03.2012
 */
@RunWith ( Suite.class)
@Suite.SuiteClasses ( {Tst_MakeUniqueStrings.class, TstSuite_Log.class  })
public class TstSuite_Tools
{

}


