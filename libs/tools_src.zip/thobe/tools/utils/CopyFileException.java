/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Tools
 */
package thobe.tools.utils;

/**
 * @author Thomas Obenaus
 * @source CopyFileException.java
 * @date 10.03.2010
 */
public class CopyFileException extends Exception
{
	public CopyFileException( String msg )
	{
		super( msg );
	}
}


