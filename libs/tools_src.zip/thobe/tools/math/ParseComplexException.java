/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Tools
 */
package thobe.tools.math;

/**
 * @author Thomas Obenaus
 * @source ParseComplexException.java
 * @date 01.07.2009
 */
public class ParseComplexException extends Exception
{
	public ParseComplexException( String cause )
	{
		super( cause );
	}
}
